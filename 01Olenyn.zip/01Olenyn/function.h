#pragma once
double mycos(double x, double epsilon);
double pokaznukova(int a, int x);
float sh(double x);
double mySh(double x, double eps);

double myLogarufmichna(double x, double eps);