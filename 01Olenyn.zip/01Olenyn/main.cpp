﻿#include <iostream>
#include "function.h"
#include <math.h>
// Îëåíèí Ñîô³ÿ ãðóïà ¹4 
using namespace std;
int main() {
	cout.precision(17);
	

	const double epselon1 = 0.0000001;
	const double epselon2 = 0.001;
	const double epselon3 = 0.1;

	const int A1 = 39;
	const int A2 = 1;
	const int A3 = 0;
	const int A4 = -1;
	const int A5 = -39;
	const int A6 = 100;
	const int A7 = 1000;
	const int A8 = -39;
	const int A9 = 100;
	const int A10 = 9;

	

	cout << "Cos " << A1 << " epselon: " << "0.0000001 " << endl;
	cout << " " << mycos(A1, epselon1) << endl;
	cout << "Rigt answer: " << cos(A1) << endl;
	cout << endl;
	cout << "Cos " << A2 << " epselon: " << "0.0000001 " << endl;
	cout << " " << mycos(A2, epselon1) << endl;
	cout << "Rigt answer: " << cos(A2) << endl;
	cout << endl;
	cout << "Cos " << A3 << " epselon: " << "0.0000001 " << endl;
	cout << " " << mycos(A3, epselon1) << endl;
	cout << "Rigt answer: " << cos(A3) << endl;
	cout << endl;
	cout << "Cos " << A4 << " epselon: " << "0.0000001 " << endl;
	cout << " " << mycos(A4, epselon1) << endl;
	cout << "Rigt answer: " << cos(A4) << endl;
	cout << endl;
	cout << "Cos " << A4 << " epselon: " << "0.0000001 " << endl;
	cout << " " << mycos(A4, epselon1) << endl;
	cout << "Rigt answer: " << cos(A4) << endl;
	cout << endl;
	cout << "Cos " << A5 << " epselon: " << "0.0000001 " << endl;
	cout << " " << mycos(A5, epselon1) << endl;
	cout << "Rigt answer: " << cos(A5) << endl;
	cout << endl;
	cout << "Cos " << A6 << " epselon: " << "0.0000001 " << endl;
	cout << " " << mycos(A6, epselon1) << endl;
	cout << "Rigt answer: " << cos(A6) << endl;
	cout << endl;
	cout << "Cos " << A7 << " epselon: " << epselon2 << endl;
	cout << " " << mycos(A7, epselon2) << endl;
	cout << "Rigt answer: " << cos(A7) << endl;
	cout << endl;
	cout << "Cos " << A8 << " epselon: " << epselon2 << endl;
	cout << " " << mycos(A8, epselon1) << endl;
	cout << "Rigt answer: " << cos(A8) << endl;
	cout << endl;
	cout << "Cos " << A9 << " epselon: " << epselon2 << endl;
	cout << " " << mycos(A9, epselon1) << endl;
	cout << "Rigt answer: " << cos(A9) << endl;
	cout << endl;
	cout << "Cos " << A10 << " epselon: " << epselon2 << endl;
	cout << " " << mycos(A10, epselon1) << endl;
	cout << "Rigt answer: " << cos(A10) << endl;

	cout << "///////////////////////////// "  << endl;


	const int B1 = 2;
	const int C1 = 0;
	const int C2 = 1;
	const int C3 = 2;
	const int C4 = -2;
	const int C5 = -5;
	const int B2 = 5;
	const int B3 = 8;
	const int B4 = 2;



	cout << "    Pokaznukova   " << endl;
	cout << B1 << "^" << C1<<" = " << pokaznukova(B1, C1) << endl;
	cout << "Rigt answer: " << pow(B1, C1) << endl;
	cout << endl;
	cout << B1 << "^" << C2 << " = " << pokaznukova(B1, C2) << endl;
	cout << "Rigt answer: " << pow(B1, C2) << endl;
	cout << endl;
	cout << B1 << "^" << C3 << " = " << pokaznukova(B1, C3) << endl;
	cout << "Rigt answer: " << pow(B1, C3) << endl;
	cout << endl;
	cout << B1 << "^" << C4 << " = " << pokaznukova(B1, C4) << endl;
	cout << "Rigt answer: " << pow(B1, C4) << endl;
	cout << endl;
	cout << B1 << "^" << C5 << " = " << pokaznukova(B1, C5) << endl;
	cout << "Rigt answer: " << pow(B1, C5) << endl;
	cout << endl;
	cout << B2 << "^" << C3 << " = "<< pokaznukova(B2, C3) << endl;
	cout << "Rigt answer: " << pow(B2, C3) << endl;
	cout << endl;
	cout << B3 << "^" << C3 << " = " << pokaznukova(B3, C3) << endl;
	cout << "Rigt answer: " << pow(B3, C3) << endl;
	cout << endl;
	cout << B4 << "^" << C4 << " = " << pokaznukova(B4, C4) << endl;
	cout << "Rigt answer: " << pow(B4, C4) << endl;
	cout << endl;
	cout << B4 << "^" << C3 << " = " << pokaznukova(B4, C3) << endl;
	cout << "Rigt answer: " << pow(B4, C3) << endl;
	cout << endl;
	cout << B2 << "^" << C5 << " = " << pokaznukova(B2, C5) << endl;
	cout << "Rigt answer: " << pow(B2, C5) << endl;
	cout << endl;
	cout << "///////////////////////////// " << endl;


	const int L1 = 1;
	const int L2 = 5;
	const int L3 = 10;
	const int L4 = 25;
	const int L5 = 50;
	const int L6 = 70;
	const int L7 = 80;
	const int L8 = 100;


	cout << "Ln(" << L1 << ")" << " epselon: " << "0.1 " << endl;
	cout << " " << myLogarufmichna(L1, epselon3) << endl;
	cout << "Rigt answer: " << log(L1) << endl;
	cout << endl;
	cout << "Ln(" << L2 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << myLogarufmichna(L2, epselon1) << endl;
	cout << "Rigt answer: " << log(L2) << endl;
	cout << endl;
	cout << "Ln(" << L3 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << myLogarufmichna(L3, epselon1) << endl;
	cout << "Rigt answer: " << log(L3) << endl;
	cout << endl;
	cout << "Ln(" << L4 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << myLogarufmichna(L4, epselon1) << endl;
	cout << "Rigt answer: " << log(L4) << endl;
	cout << endl;
	cout << "Ln(" << L5 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << myLogarufmichna(L5, epselon1) << endl;
	cout << "Rigt answer: " << log(L5) << endl;
	cout << endl;
	cout << "Ln(" << L6 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << myLogarufmichna(L6, epselon1) << endl;
	cout << "Rigt answer: " << log(L6) << endl;
	cout << endl;
	cout << "Ln(" << L7 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << myLogarufmichna(L7, epselon1) << endl;
	cout << "Rigt answer: " << log(L7) << endl;
	cout << endl;
	cout << "Ln(" << L8 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << myLogarufmichna(L8, epselon1) << endl;
	cout << "Rigt answer: " << log(L8) << endl;
	cout << endl;
	cout << "Ln(" << L3 << ")" << " epselon: " << epselon2 << endl;
	cout << " " << myLogarufmichna(L3, epselon2) << endl;
	cout << "Rigt answer: " << log(L3) << endl;
	cout << endl;
	cout << "Ln(" << L5 << ")" << " epselon: " << epselon2 << endl;
	cout << " " << myLogarufmichna(L5, epselon2) << endl;
	cout << "Rigt answer: " << log(L5) << endl;
	cout << endl;

	const int D1 = 10;
	const int D2 = 2;
	const int D3 = 0;
	const int D4 = -1;
	const int D5 = -10;
	const int D6 = 36;
	const int D7 = -36;
	const int D8 = 5;

	cout << "///////////////////////////// " << endl;

	cout << "    Giperbolichnuy sin   " << endl;
	cout << "Sh(" << D2 << ")" << " epselon: " << "0.1 " << endl;
	cout << " " << mySh(D2, 0.1) << endl;
	cout << "Rigt answer: " << sinh(D2) << endl;
	cout << endl;
	cout << "Sh(" << D3 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << mySh(D3, epselon1) << endl;
	cout << "Rigt answer: " << sinh(D3) << endl;
	cout << endl;
	cout << "Sh(" << D4 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << mySh(D4, epselon1) << endl;
	cout << "Rigt answer: " << sinh(D4) << endl;
	cout << endl;
	cout << "Sh(" << D1 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << mySh(D1, epselon1) << endl;
	cout << "Rigt answer: " << sinh(D1) << endl;
	cout << endl;
	cout << "Sh(" << D5 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << mySh(D1, epselon1) << endl;
	cout << "Rigt answer: " << sinh(D5) << endl;
	cout << endl;
	cout << "Sh(" << D6 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << mySh(D6, epselon1) << endl;
	cout << "Rigt answer: " << sinh(D5) << endl;
	cout << endl;
	cout << "Sh(" << D7 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << mySh(D7, epselon1) << endl;
	cout << "Rigt answer: " << sinh(D7) << endl;
	cout << endl;
	cout << "Sh(" << D8 << ")" << " epselon: " << "0.0000001 " << endl;
	cout << " " << mySh(D8, epselon1) << endl;
	cout << "Rigt answer: " << sinh(D8) << endl;
	cout << endl;
	cout << "Sh(" << D1 << ")" << " epselon: " << epselon2 << endl;
	cout << " " << mySh(D1, epselon2) << endl;
	cout << "Rigt answer: " << sinh(A1) << endl;
	cout << endl;
	cout << "Sh(" << D1 << ")" << " epselon: " << epselon2 << endl;
	cout << " " << mySh(D1, epselon2) << endl;
	cout << "Rigt answer: " << sh(A1) << endl;
	cout << endl;














	






}