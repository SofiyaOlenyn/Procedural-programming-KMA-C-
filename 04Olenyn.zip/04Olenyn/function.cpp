
using namespace std;
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cmath>
double Mediym( double a,  double b) {
	if ((b > 0 && a > b)) { cout << "error"; return -1; };
	double a0(a), b0(b), a1(0), b1(0);
	while ((a != b1) || (b != a1) || (b<a)) {
		a1 = sqrt(a * b);
		b1 = (a + b) / 2;
		a = a1;
		b = b1;
	}
	return a;


}

