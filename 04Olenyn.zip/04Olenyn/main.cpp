
#include "function.h";
using namespace std;
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cmath>

using namespace std;
int main() {
	const double a0(2), a1(6), a2(2.5), a3(7.5), a4(10.5), a5(30);
	const double b0(6), b1(24), b2(7), b3(10.5), b4(50), b5(45.5);
	cout << "Arithmetic-geometric mean :" << endl;
	cout.precision(15);
	cout << "M(" << a0 << " ; " << b0 << ") = " << Mediym(a0, b0) << endl;
	cout << "M(" << a1 << " ; " << b1 << ") = " << Mediym(a1, b1) << endl;
	cout << "M(" << a2 << " ; " << b2 << ") = " << Mediym(a2, b2) << endl;
	cout << "M(" << a3 << " ; " << b3 << ") = " << Mediym(a3, b3) << endl;
	cout << "M(" << a4 << " ; " << b4 << ") = " << Mediym(a4, b4) << endl;
	cout << "M(" << a5 << " ; " << b5 << ") = " << Mediym(a5, b5) << endl;
	
	return 0;
}