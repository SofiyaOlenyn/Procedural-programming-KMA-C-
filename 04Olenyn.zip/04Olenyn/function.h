#pragma once
double Mediym(double a, double b);