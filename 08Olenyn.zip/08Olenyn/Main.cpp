#include <iostream>
#include "function.h"
#include "structurer.h"
using namespace std;
int main() {
	const double         a0(2), a1(-3), a2(-5), a3(2.5), a4(-2.5); 
	const unsigned int    b0(6), b1(9), b2(3), b3(7), b4(8);
	
	cout << "Power:" << endl;
	cout << a0 <<"^"<< b0 << " = " << power(a0, b0) << endl;
	cout << a1 << "^" << b1 << " = " << power(a1, b1) << endl;
	cout << a2 << "^" << b2 << " = " << power(a2, b2) << endl;
	cout << a3 << "^" << b3 << " = " << power(a3, b3) << endl;
	cout << a4 << "^" << b4 << " = " << power(a4, b4) << endl;

	const int n(1), n1(2), n2(5), n3(10), n4(20), n5(6), n6(3), n7(4);
	cout << "Fibonacci:" << endl;
	cout << "number " << n << " = " << Fibonaci(n) << endl;
	cout << "number " << n1 << " = " << Fibonaci(n1) << endl;
	cout << "number " << n6 << " = " << Fibonaci(n6) << endl;
	cout << "number " << n7 << " = " << Fibonaci(n7) << endl;
	cout << "number " << n2 << " = " << Fibonaci(n2) << endl;
	cout << "number " << n5 << " = " << Fibonaci(n5) << endl;
	cout << "number " << n3 << " = " << Fibonaci(n3) << endl;
	cout << "number " << n4 << " = " << Fibonaci(n4) << endl;

	cout << "Fibonacci recursion:" << endl;
	cout << "number " << n << " = " << quickFib(n) << endl;
	cout << "number " << n1 << " = " << quickFib(n1) << endl;
	cout << "number " << n6 << " = " << quickFib(n6) << endl;
	cout << "number " << n7 << " = " << quickFib(n7) << endl;
	cout << "number " << n2 << " = " << quickFib(n2) << endl;
	cout << "number " << n5 << " = " << quickFib(n5) << endl;
	cout << "number " << n3 << " = " << quickFib(n3) << endl;
	cout << "number " << n4 << " = " << quickFib(n4) << endl;

	system("pause");
}