   

#include <iostream>
#include <math.h>
#include <iostream>
#include "function.h"
#include "structurer.h"
using namespace std;
#define _USE_MATH_DEFINES
//1
void zet(double& y, double& x, unsigned int& k, int& count)
{    
	if (k > 0)
		
	{
		if (k % 2 == 1)
		{
			y *= x; k--;
		}
		else
		{     
			x *= x; k /= 2;
		};
		count++;
		zet(y, x, k, count);
	}
}

double power(double x, unsigned int n)
{
	double y = 1;
	int count = 0;
	zet(y, x, n, count);
	cout << "Amount of steps: " << count << "      ";
	return y;
}
//2

void fib(double& f1, double& f2, unsigned int n, int& count)
{
	
	if (n >= 2)
	{   
		double f = f2; f2 += f1; f1 = f;
		count++;
		fib(f1, f2, n - 1,count);
	}
};
double Fibonaci(unsigned int n)
{
	int count(0);
	double f0 = 0, f1 = 1;
	switch (n)
	{
	case 0:
		cout << "Amount of steps: " << count << "      ";
		return f0; break;
	case 1:
		cout << "Amount of steps: " << count << "      ";
		return f1; break;
	default:
		fib(f0, f1, n,count);
		cout << "Amount of steps: " << count << "      ";
		return f1;
	}
};


//3
const Matrix2x2 unitMatrix = { 1,0,0,1 };
//recursion 
template <typename Type> const Type& quickPower(const Type& base, const int exponent, const Type& y = 1) { 
       if(exponent==0) return y; 
	   if(exponent%2==0)      
	   return quickPower(base*base, exponent/2, y); 
	   return quickPower(base, exponent-1, y*base); }



const Matrix2x2 operator* (const Matrix2x2& a, const Matrix2x2& b) { 
   Matrix2x2 res = {a._11*b._11+a._12*b._21,a._11*b._21+a._12*b._22,  
	a._21*b._11+a._22*b._21,a._21*b._21+a._22*b._22  };   

     return res; 
} 

const Vector2 operator* (const Matrix2x2& a, const Vector2& v) {
Vector2 res = {a._11*v._1+a._12*v._2, a._21*v._1+a._22*v._2};  
return res; } 


int quickFib(int n) { 
	Matrix2x2 fibMatrix={1,1,1,0}; Vector2 fibVector={1, 0};   
	Vector2 fibRes=quickPower(fibMatrix, n-1, unitMatrix)*fibVector;   
	return fibRes._1; } 
