#pragma once
int quickFib(int n);
void zet(double& y, double& x, unsigned int& k, int& count);
double power(double x, unsigned int n);
double Fibonaci(unsigned int n);
void fib(double& f1, double& f2, unsigned int n, int& count);