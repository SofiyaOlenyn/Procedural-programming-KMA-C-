#pragma once
double suma(double x, double n);
double sin(double x, double epsilon);
int ostachya(int a, int b);
int evklid(int a, int b);
int evklid2(int a, int b);
int compare(int a, int b);
int Chebeshew(int x, int n);
