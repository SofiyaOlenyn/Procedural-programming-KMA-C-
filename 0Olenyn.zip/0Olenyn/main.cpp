#include <iostream>
#include "function.h"
// ������ ����� ����� �4 
using namespace std;
int main() {
	cout << "TASK1"<< endl;
	cout << "Sum x=2 n=4: " << suma(2, 4) << endl;
	cout << "Sum x=0 n=5: " << suma(0, 5) << endl;
	cout << "Sum x=2 n=0: " << suma(2, 0) << endl;
	cout << "Sum x=2 n=1: " << suma(2, 1) << endl;
	cout << "Sum x=1 n=2: " << suma(1, 2) << endl;
	cout << endl;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	cout << endl;
	cout << "TASK2" << endl;
	cout << "sin 100 " << endl;
	cout << sin(100, 0.00001) << endl;
	cout << "sin 0 " << endl;
	cout << sin(0, 0.00001) << endl;
	cout << "sin 1 " << endl;
	cout << sin(1, 0.00001) << endl;
	cout << "sin -56 " << endl;
	cout << sin(-56, 0.001) << endl;
	cout << "sin 20 " << endl;
	cout << sin(20, 0.1) << endl;
	cout << endl;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	cout << endl;
	cout << "TASK3" << endl;
	cout << "16 divide by 3. ";
	cout << ostachya(16, 3) << endl;
	cout << "3 divide by 16: ";
	cout << ostachya(3, 16) << endl;
	cout << "123 divide by 3: ";
	cout << ostachya(125, 3) << endl;
	cout << "16 divide by 0: ";
	cout << ostachya(16, 0) << endl;
	cout << "0 divide by 3: ";
	cout << ostachya(0, 3) << endl;
	cout << endl;

	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	cout << endl;
	cout << "TASK4" << endl;

	cout << " GCD 6 and 10 " << endl;
	cout << "Recursion:";
	cout << evklid(6, 10) << endl;
	cout << "Cycle: ";
	cout << evklid2(6, 10) << endl;
	cout << compare(evklid(6, 10), evklid2(6, 10)) << endl;
	cout << endl;
	cout << " GCD 10 and 6 " << endl;
	cout << "Recursion:";
	cout << evklid(10, 6) << endl;
	cout << "Cycle: ";
	cout << evklid2(10, 6) << endl;
	cout << compare(evklid(10, 6), evklid2(10, 6)) << endl;
	cout << endl;
	cout << " GCD 6 and 0 " << endl;
	cout << "Recursion:";
	cout << evklid(6, 0) << endl;
	cout << "Cycle: ";
	cout << evklid2(6, 0) << endl;
	cout << compare(evklid(6, 0), evklid2(6, 0)) << endl;
	cout << endl;
	cout << " GCD 0 and 0 " << endl;
	cout << "Recursion:";
	cout << evklid(0, 0) << endl;
	cout << "Cycle: ";
	cout << evklid2(0, 0) << endl;
	cout << compare(evklid(0, 0), evklid2(0, 0)) << endl;
	cout << endl;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	cout << endl;
	cout << "TASK5" << endl;
	cout << "x=2, n=3: ";
	cout << Chebeshew(2, 3) << endl;
	cout << "x=1, n=3: ";
	cout << Chebeshew(1, 3) << endl;
	cout << "x=0, n=3: ";
	cout << Chebeshew(0, 3) << endl;
	cout << "x=3, n=-1: ";
	cout << Chebeshew(3, -1) << endl;
	cout << "x=-1, n=4: ";
	cout << Chebeshew(1, 4) << endl;

	return 0;

}
