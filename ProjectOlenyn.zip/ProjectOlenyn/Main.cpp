#include <iostream>
#include "PascalTriangle.h"
using namespace std;
int main() {
	const unsigned int    n0(3), n1(5), n2(8), n3(12), n4(20);
	cout << "Pascal Triangle:" << endl;
	cout << "N=" << n0<< endl;
	PascalTriangle(n0);
	cout << "N=" << n1 << endl;
	PascalTriangle(n1);
	cout << "N=" << n2 << endl;
	PascalTriangle(n2);
	cout << "N=" << n3 << endl;
	PascalTriangle(n3);
	cout << "N=" << n4 << endl;
	PascalTriangle(n4);
	
	system("pause");
}