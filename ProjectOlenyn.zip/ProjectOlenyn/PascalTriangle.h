#pragma once
void PascalTriangle(int n);
int coefficient(int n, int k);