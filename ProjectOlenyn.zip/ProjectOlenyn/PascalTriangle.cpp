
#include <iostream>
using namespace std;
int coefficient(int n, int k)
{
	int result = 1;
	if (k > n - k) {
		k = n - k;
	}
	for (int i = 0; i < k; ++i)
	{
		result = result*(n - i);
		result = result/(i + 1);
	}

	return result;
}
void PascalTriangle(int n)
{
	for (int line = 0; line < n; line++)
	{
		for (int i = 0; i <= line; i++) {
			cout << " " << coefficient(line, i);
		}

		cout<< endl;
	}
}
