#include <cmath>

double fnca;
double fncb;

double ellipse(double x)
{
	return (1 / sqrt(fnca * fnca * pow(sin(x), 2) + fncb * fncb * pow(cos(x), 2)));
}

double dirichlet(double x)
{
	return (sin(fnca * x) / x);
}

double poisson(double x)
{
	return (exp(-(x * x)));
}

double euler(double x)
{
	return (pow(x, fnca - 1) / (1 + x));
}

double simpson(double(*const f)(double), const double a, const double b, const double eps)
{

	fnca = a;
	fncb = b;

	int n = 2;

	double h = (b - a) / 2;

	double s1 = h * (f(a) + f(b));
	double s2 = 0;
	double s4 = 4 * h * f(a + h);

	double prevS = 0;
	double curS = s1 + s2 + s4;

	do {
		prevS = curS;

		n *= 2;
		h /= 2;
		s1 /= 2;
		s2 = s2 / 2 + s4 / 4;
		s4 = 0;

		int i = 1;

		do {
			s4 = s4 + f(a + i * h);
			i += 2;
		} while (i <= n);

		s4 = 4 * h * s4;
		curS = s1 + s2 + s4;

	} while (fabs(curS - prevS) > eps);

	return curS / 3;
}