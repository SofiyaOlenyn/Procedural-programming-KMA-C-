#include <iostream>
#include "Simpson.h"
#include <math.h>
#include <iostream>
#include <cmath>


using namespace std;

int main() {

	const double a (0.001);
	const double b (8);
	cout << "a = " << a << ", b = " << b << endl;
	cout << "Ellipse: " << simpson(ellipse, a, b, 0.00001) << endl;
	cout << "Dirichlet: " << simpson(dirichlet, a, b, 0.00001) << endl;
	cout << "Poisson: " << simpson(poisson, a, b, 0.00001) << endl;
	cout << "Euler: " << simpson(euler, a, b, 0.00001) << endl << endl;
	const double a1(0.5);
	const double b1(10);
	cout << "a = " << a1 << ", b = " << b1 << endl;
	cout << "Ellipse: " << simpson(ellipse, a1, b1, 0.00001) << endl;
	cout << "Dirichlet: " << simpson(dirichlet, a1, b1, 0.00001) << endl;
	cout << "Poisson: " << simpson(poisson, a1, b1, 0.00001) << endl;
	cout << "Euler: " << simpson(euler, a1, b1, 0.00001) << endl << endl;
	const double a2(0.9);
	const double b2(14);
	cout << "a = " << a2 << ", b = " << b2 << endl;
	cout << "Ellipse: " << simpson(ellipse, a2, b2, 0.00001) << endl;
	cout << "Dirichlet: " << simpson(dirichlet, a2, b2, 0.00001) << endl;
	cout << "Poisson: " << simpson(poisson, a2, b2, 0.00001) << endl;
	cout << "Euler: " << simpson(euler, a2, b2, 0.00001) << endl << endl;


	

	system("pause");
}