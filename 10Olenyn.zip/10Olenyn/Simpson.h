#pragma once

double ellipse(double x);
double dirichlet(double x);
double poisson(double x);
double euler(double x);
double simpson(double(*const f)(double), const double a, const double b, const double eps);