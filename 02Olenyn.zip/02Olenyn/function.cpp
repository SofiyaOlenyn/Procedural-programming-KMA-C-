#include <iostream>
#include <math.h>
#define _USE_MATH_DEFINES
# define M_PI           3.14159265358979323846  /* pi */
using namespace std;

double power(double a, int n, int& count) {
	count = 0;
	if (n < 0) { cout << "error x"; return -1; }
	double result (1);
	if (n > 0) {
		for (int i = 1; i <= n; i++)
		{
			result = result * a;
			count++;
		};
	}
	return result;
}

double countCounter(double a, int n, int& count) {
	count = 0;
	if (n < 0) { cout << "error x"; return -1; }
	double result(1);
	if (n > 0) {
		for (int i = 1; i <= n; i++)
		{
			result = result * a;
			count++;
		};
	}
	return count;
}

double QuickPower(double x, int n, int& count) {
	int count2 = 0;
	count=0;
	if (n < 0) { cout << "error x"; return -1; }
	double result(1);
	if (n == 0) {  return 1; }
		count++;
		if (n % 2 == 0) {
			double half = power(x, n / 2, count2);
			count == countCounter(x, n / 2, count)+1;
			return half * half;
		}
		else {
			double half = power(x, (n - 1) / 2, count2);
			count == countCounter(x, n / 2, count)+2;
			return x * half * half;
		}
}
double powerRecursion(double x, int n, int& count)
{

	if (n == 0) return 1;
	count++;
	return x * powerRecursion(x, n - 1, count);
}

double QuickPowerRecursion(double x, int n, int& count)
{
	
	    count++;
		double m;
		if (n == 0) return 1;
		if (n % 2 == 0) {
			m = QuickPowerRecursion(x, n / 2, count);
			return m * m;
		}
		else return x * QuickPowerRecursion(x, n - 1, count);
	

}

