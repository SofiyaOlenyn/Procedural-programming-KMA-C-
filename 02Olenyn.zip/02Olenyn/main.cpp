#include <iostream>
#include "function.h"

using namespace std;
int main() {
	
	/* 
	   The most effective - QuickPower;
	   then - QuickPowerRecursion;
	   the least effective - Power, PowerRecursion.
	*/

	double a0(2), a1(-3), a2(2.5);
	int    b0(6), b1(9), b2(7);
	int   count0(0), count1(0), count2(0), count3(0);
	cout <<a0<< "^" << b0 << endl;
	cout << "Power: ";
	cout << power(a0, b0, count0);
	cout << "  Steps: ";
	cout << count0 << endl;
	cout << "QuickPower: ";
	cout << QuickPower(a0, b0, count1);
	cout << "  Steps: ";
	cout << count1 << endl;
	cout << "PowerRecursion: ";
	cout << powerRecursion(a0, b0, count3);
	cout << "  Steps: ";
	cout << count3 << endl;
	cout << "QuickPowerRecursion: ";
	cout << QuickPowerRecursion(a0, b0, count2) ;
	cout << "  Steps: ";
	cout << count2 << endl;
	cout << "/////////////////////////// " << endl;
	cout << a1 << "^" << b1 << endl;
	int   count4(0), count5(0), count6(0), count7(0);
	cout << "Power: ";
	cout << power(a1, b1, count4);
	cout << "  Steps: ";
	cout << count4 << endl;
	cout << "QuickPower: ";
	cout << QuickPower(a1, b1, count5);
	cout << "  Steps: ";
	cout << count5 << endl;
	cout << "PowerRecursion: ";
	cout << powerRecursion(a1, b1, count6);
	cout << "  Steps: ";
	cout << count6 << endl;
	cout << "QuickPowerRecursion: ";
	cout << QuickPowerRecursion(a1, b1, count7);
	cout << "  Steps: ";
	cout << count7 << endl;
	cout << "/////////////////////////// " << endl;
	
	int   count8(0), count9(0), count10(0), count11(0);
	cout << a2 << "^" << b2 << endl;
	cout << "Power: ";
	cout << power(a2, b2, count8);
	cout << "  Steps: ";
	cout << count8 << endl;
	cout << "QuickPower: ";
	cout << QuickPower(a2, b2, count9);
	cout << "  Steps: ";
	cout << count9 << endl;
	cout << "PowerRecursion: ";
	cout << powerRecursion(a2, b2, count10);
	cout << "  Steps: ";
	cout << count10 << endl;
	cout << "QuickPowerRecursion: ";
	cout << QuickPowerRecursion(a2, b2, count11);
	cout << "  Steps: ";
	cout << count11 << endl;
	return 0;

}
