#pragma once
double power(double a, int x, int& count);
double QuickPower(double a, int n, int& count);
double QuickPowerRecursion(double a, int n, int& count1);
double powerRecursion(double x, int n, int& count);