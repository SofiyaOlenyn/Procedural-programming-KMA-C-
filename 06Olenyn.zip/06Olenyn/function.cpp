#include <iostream>
#include <iomanip>
#include <cassert>
using namespace std;
void bubbleSort(int* sorter,  int size, int* initial_array)
{
	int temp = 0; 
	bool exit = false; 
	while (!exit) 
	{
		exit = true;
		for (int i = 0; i < (size - 1); i++) 
			if (sorter[i] > sorter[i + 1]) 
			{
				temp = sorter[i];
				sorter[i] = sorter[i + 1];
				sorter[i + 1] = temp;
				exit = false; 
			}
	}

	cout << "Initial array: ";
	//print initial array
	for (int i = 0; i < size; i++)
	{
		cout  << initial_array[i] << "  ";
	}
	cout << "\n";
	cout << "Sorted array: ";
	// print sorter array
	for (int i = 0; i < size; i++) {
		
		     cout << sorter[i] << " ";
	}
	// check if array is sorting in ascending order
	for (int j = 0; j < size - 1; j++) {
		assert(sorter[j] <= sorter[j + 1]);
	}

	//checks if the sorted array consists only of elements of the initial array
	int k;
	for (int i = 0; i < size; i++) {
		k = 0;
		for (int j = 0; j < size; j++) {
			if (sorter[i] == initial_array[j]) { k++; }
		}
		assert(k!=0);
	}

	cout << endl;

	
}


	
	



