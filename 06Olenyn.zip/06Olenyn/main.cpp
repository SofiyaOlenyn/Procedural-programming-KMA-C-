#include "function.h"
#include <iostream>
#include <iomanip>
#include <ctime>
using namespace std;

int main()
{
	//initial array
	int size_array1(7);
	int* initial_array1 = new int[size_array1] {34, 56, 78, 23, 45, 12, 1};
	int* sorted_array1 = new int[size_array1] {34, 56, 78, 23, 45, 12, 1};

	int size_array2(10);
	int* initial_array2 = new int[size_array2] {78, 56, 23, 19, 15, 12, 9, 8, 7, 1};
	int* sorted_array2 = new int[size_array2] {78, 56, 23, 19, 15, 12, 9, 8, 7, 1};

	int size_array3(10);
	int* initial_array3 = new int[size_array3] {1, 3, -5, 0, 6, 6, 47, 78, 93, -9};
	int* sorted_array3 = new int[size_array3] {1, 3, -5, 0, 6, 6, 47, 78, 93, -9};

	int size_array4(5);
	int* initial_array4 = new int[size_array4] {4, 4, 4, 4, 4};
	int* sorted_array4 = new int[size_array4] {4, 4, 4, 4, 4};

	int size_array5(10);
	int* initial_array5 = new int[size_array5] {1, 2, 3, 4, 67, 79, 80, 81, 90, 123};
	int* sorted_array5 = new int[size_array5] {1, 2, 3, 4, 67, 79, 80, 81, 90, 123};



	bubbleSort(sorted_array1, size_array1, initial_array1);
	delete initial_array1;
	delete sorted_array1;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	bubbleSort(sorted_array2, size_array2, initial_array2); 
	delete initial_array2;
	delete sorted_array2;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	bubbleSort(sorted_array3, size_array3, initial_array3);
	delete initial_array3;
	delete sorted_array3;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	bubbleSort(sorted_array4, size_array4, initial_array4);
	delete initial_array4;
	delete sorted_array4;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	bubbleSort(sorted_array5, size_array5, initial_array5);
	delete initial_array5;
	delete sorted_array5;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;


	system("pause");
	return 0;
}