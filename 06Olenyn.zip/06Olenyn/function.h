#pragma once
void bubbleSort(int* sorter, int size, int* initial_array);

