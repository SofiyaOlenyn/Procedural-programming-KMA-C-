#pragma once
#include <iostream>
#include "smallFunctions.h"
#include "Point.h"
#include "Polinom.h";
#include <cassert>

using namespace std;

int main()
{

	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "\n TASK 1 " << endl;

	const unsigned int a(4),a1(33),a2(30);
	cout << "The num is: " << a << "  result: " << n(a) <<  endl;
	cout << "The num is: " << a1 << "  result: " << n(a1) << endl;
	cout << "The num is: " << a2 << "  result: " << n(a2) << endl;

	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "\n TASK 2 " << endl;
	const int n(5), n1(10),n2(15);
	cout << "Sum of " << n << " is " << recursivneSpividnosenya(n) << endl;
	cout << "Sum of " << n1 << " is " << recursivneSpividnosenya(n1) << endl;
	cout << "Sum of " << n2 << " is " << recursivneSpividnosenya(n2) << endl;
	/////////////////////////////////////////////////////////////////////////////////////////////////////////

	cout << "\n TASK 3 " << endl;
	const unsigned int k(1), word(255);
	const unsigned int k1(2), word1(255);
	const unsigned int k2(3), word2(255);
	const unsigned int k3(2), word3(25);
	cout << "Amount pairs n="<< k <<" in " << word  << " is " << sumOfOnes(word,k) << endl;
	cout << "Amount pairs n=" << k1 << " in " << word1 << " is " << sumOfOnes(word1, k1) << endl;
	cout << "Amount pairs n=" << k2 << " in " << word2 << " is " << sumOfOnes(word2, k2) << endl;
	cout << "Amount pairs n=" << k3 << " in " << word3 << " is " << sumOfOnes(word3, k3) << endl;

	/////////////////////////////////////////////////////////////////////////////////////////////////////////

	cout << "\n TASK 4 " << endl;

	const unsigned int s(23), s1(56),s2(2);
	cout << "n=" << s << "  Swapped is " << swap1(s) << endl;
	cout << "n=" << s1 << "  Swapped is " << swap1(s1) << endl;
	cout << "n=" << s2 << "  Swapped is " << swap1(s2) << endl;
	unsigned int swapted = swap1(s);

	//cheak
	assert(swap1(swapted) == s);

	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "\n TASK 5 " << endl;
	
	cout << "n=" << s << " Swapped is " << swap2(s) << endl;
	cout << "n=" << s1 << " Swapped is " << swap2(s1) << endl;
	cout << "n=" << s2 << " Swapped is " << swap2(s2) << endl;
	unsigned int swapted2 = swap2(s);

	//cheak
	assert(swap2(swapted2) == s);


	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	cout << "\n TASK 6 " << endl;
	const double b(3);
	double** systeme = new double* [b]; 
	for (int count = 0; count < b; count++)
		systeme[count] = new double[4];
	systeme[0][0] = 2;
	systeme[0][1] = 4;
	systeme[0][2] = 7;
	systeme[0][3] = 8;
	systeme[1][0] = 3;
	systeme[1][1] = 3;
	systeme[1][2] = 3;
	systeme[1][3] = 3;
	systeme[2][0] = 9;
	systeme[2][1] = 4;
	systeme[2][2] = 2;
	systeme[2][3] = 1;

	cout << "Center for" << endl;
    cout <<"M  X  Y  Z" << endl;
	cout << systeme[0][0] << "  " << systeme[0][1] << "  " << systeme[0][2] << "  " << systeme[0][3] << endl;
	cout << systeme[1][0] << "  " << systeme[1][1] << "  " << systeme[1][2] << "  " << systeme[1][3] << endl;
	cout << systeme[2][0] << "  " << systeme[2][1] << "  " << systeme[2][2] << "  " << systeme[2][3] << endl;
	cout <<" X: "<< tsentrmas(systeme,'x',3) << " Y: " << tsentrmas(systeme, 'y', 3) << " Z: " << tsentrmas(systeme, 'z', 3) << endl;
	for (int count = 0; count < b; count++)
		delete[]systeme[count];
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "\n TASK 7 " << endl;
	const double b1(3);
	Point* systema = new Point [b1]; 
	Point M1, M2, M3;
	M1._m = 1; M1._x = 2; M1._y = 3; M1._z = 4;
	M2._m = 2; M2._x = 5; M2._y = 10; M2._z = 4;
	M3._m = 1; M3._x = -4; M3._y = 3; M3._z = 8;
	systema[0]=M1; systema[1] = M2; systema[2] = M3;
	cout << "Center for" << endl;
	cout << "M  X  Y  Z" << endl;
	cout << M1._m << "  " << M1._x << "  " << M1._y << "  " << M1._z << endl;
	cout << M2._m << "  " << M2._x << "  " << M2._y << "  " << M2._z << endl;
	cout << M3._m << "  " << M3._x << "  " << M3._y << "  " << M3._z << endl;
	cout << " X: " << tsentrmas2(systema, 'x', 3) << " Y: " << tsentrmas2(systema, 'y', 3) << " Z: " << tsentrmas2(systema, 'z', 3) << endl;
	delete[]systema; 
	systema = 0;
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "\n TASK 8 " << endl;
	
	Point1* systema1 = new Point1[3];
	Point1 L1, L2, L3;
	 L1._x = 2; L1._y = 3; L1._z = 4;
	 L2._x = 5; L2._y = 10; L2._z = 4;
	 L3._x = -4; L3._y = 3; L3._z = 8;
	systema1[0] = L1; systema1[1] = L2; systema1[2] = L3;
	cout << "Center for" << endl;
	cout << "X  Y  Z" << endl;
	cout  << L1._x << "  " << L1._y << "  " << L1._z << endl;
	cout << L2._x << "  " << L2._y << "  " << L2._z << endl;
	cout << L3._x << "  " << L3._y << "  " << L3._z << endl;
	cout << " X: " << tsentrmas3(massa, systema1, 'x', 3) << " Y: "
		<< tsentrmas3(massa, systema1, 'y', 3) << " Z: " << tsentrmas3(massa, systema1, 'z', 3) << endl;
	
	delete[]systema1;
	systema1 = 0;
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "\n TASK 9 " << endl;
	

	const int n0(3), x1(4), x2(-2), x3(1);
	
	Polynom2 PP1, PP2;

	PP1._n = 3;
	PP1._coeff[0] = 5; PP1._exponenta[0] = 3;
	PP1._coeff[1] = 1; PP1._exponenta[1] = 4;
	PP1._coeff[2] = 4; PP1._exponenta[2] = 6;

	PP2._n = 3;
	PP2._coeff[0] = 1; PP2._exponenta[0] = 3;
	PP2._coeff[1] = 2; PP2._exponenta[1] = 4;
	PP2._coeff[2] = 1; PP2._exponenta[2] = 7;
	cout << "Polynom:  " << PP1._coeff[0] << "x^" << PP1._exponenta[0] << "+"
		<< PP1._coeff[1] << "x^" << PP1._exponenta[1] << "+"
		<< PP1._coeff[2] << "x^" << PP1._exponenta[2] << endl;

	cout << "x = " << x1 << " result: " << rozriddzenyiMnogochlen1(n0, x1, PP1) << endl;
	cout << "x = " << x2 << " result: " << rozriddzenyiMnogochlen1(n0, x2, PP1) << endl;
	cout << "x = " << x3 << " result: " << rozriddzenyiMnogochlen1(n0, x3, PP1) << endl;


	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "\n TASK 10" << endl;

		
		cout << "Polynom 1:  " << PP1._coeff[0] << "x^" << PP1._exponenta[0] << "+"
			<< PP1._coeff[1] << "x^" << PP1._exponenta[1] << "+"
			<< PP1._coeff[2] << "x^" << PP1._exponenta[2] << endl;
		cout << "Polynom 2:  " << PP2._coeff[0] << "x^" << PP2._exponenta[0] << "+"
			<< PP2._coeff[1] << "x^" << PP2._exponenta[1] << "+"
			<< PP2._coeff[2] << "x^" << PP2._exponenta[2] << endl;
		
		
      Polynom2 PP3= PP1+PP2;
	  cout << "Result:  " << PP3._coeff[0] << "x^" << PP3._exponenta[0] << "+"
		  << PP3._coeff[1] << "x^" << PP3._exponenta[1] << "+"
		  << PP3._coeff[2] << "x^" << PP3._exponenta[2] 
		  << "+" << PP3._coeff[3] << "x^" << PP3._exponenta[3] << endl;
	

	system("pause");
	return 0;
}