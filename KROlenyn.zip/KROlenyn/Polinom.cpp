

#include "structures.h"
#include <iostream>
#include <cassert>
using namespace std;
//9

 double rozriddzenyiMnogochlen1(int n, int x, Polynom2 p) {
	double s(0);
	for (int i = 0; i < n; i++) {
		double stepin;
		double base = x; int exponent = p._exponenta[i]; double y = 1;
		while (exponent > 0) {
			if (exponent % 2 == 0) { base = base * base; exponent = exponent / 2; }
			else { y = y * base; exponent = exponent - 1; }
		}
		s = s + p._coeff[i] * y;
	}
	return s;
};

//10 operator is in "Polinom.h"


	
