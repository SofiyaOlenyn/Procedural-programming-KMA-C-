#include <iostream>
#include <cassert>
using namespace std;
//task 1

const int n(const unsigned int x)
{
	const unsigned int n = x;
	assert((~x ? x : 0xFFFFFFFF) == n);
	return n;
}
//task2

//function for cheaking my function
double cheakRecursivneSpividnosenya(const int n)
{
	double a(0);
	double s(0);
	for (int i = 1; i <= n; i++) {
		a += (i * i) * pow(2, n - i) ;
		
	}
	return a;
}

//my function
double recursivneSpividnosenya(const int n)
{
	double a=n*n;
	double s = a;
	for (int i = n-1; i >=1; i--) {
		a = a * 2*i*i/(i+1)/(i+1);
		s = s + a;
	}
	assert(cheakRecursivneSpividnosenya(n) == s);
	return s;
}



//task 3
unsigned int sumOfOnes(const unsigned int wordinput, const unsigned int n) {
	unsigned int word = wordinput, count(0), k(0);
	while (word)
	{
		k = 0;
		while ( word & 1)
		{
			
			k++;
			word >>= 1;
			if (k == n) {
				count++;
				
				if (word % 2) k--;
				
			}
		}
		word >>= 1;
	}
	return count;

}

//task 4
unsigned int swap1(unsigned int x)
{
	unsigned int even = x & 0xAAAAAAAA;
	unsigned int odd = x & 0x55555555;
	even >>= 1;   
	odd <<= 1; 
	unsigned int result = (even | odd);

	return result;
}

//task 5
int swap2(int x)
{  
	int a, b, result;
	a = (x & 0x0F) << 4;
	b = (x & 0xF0) >> 4;
	result = a | b;
	return result;
}



 

