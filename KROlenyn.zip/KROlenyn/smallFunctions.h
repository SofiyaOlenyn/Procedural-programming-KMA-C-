const int n(const unsigned int x);
double recursivneSpividnosenya(const int n);
double cheakRecursivneSpividnosenya(const int n);
unsigned int sumOfOnes(const unsigned int wordinput, const unsigned int n);
unsigned int swap1(unsigned int x);
int swap2(int x);