#pragma

double rozriddzenyiMnogochlen1(int n, int x, Polynom2 p);


//task �10
Polynom2 operator+(Polynom2& p11, Polynom2& p22) {
	Polynom2 p3;
	Polynom2 p1 = p11;
	Polynom2 p2 = p22;
	int k(-1);
	for (int j = 0; j <= p1._n; j++)
	{
		for (int i = 0; i < p2._n; i++) {
			if (p1._exponenta[j] == p2._exponenta[i]) {
				k++;
				p3._coeff[k] = p1._coeff[j] + p2._coeff[i];
				p3._exponenta[k] = p1._exponenta[j];
				p2._coeff[k] = 0;
				break;
			}
			if (p1._exponenta[j] != p2._exponenta[(p2._n) - 1]) {
				k++;
				p3._coeff[k] = p1._coeff[j];
				p3._exponenta[k] = p1._exponenta[j];
			}
		}


	}
	for (int i = 0; i < p2._n; i++) {
		if (p2._coeff[i] != 0) {
			k++;
			p3._coeff[k] = p2._coeff[i];
			p3._exponenta[k] = p2._exponenta[i];


		}


	}
	

	return p3;


}