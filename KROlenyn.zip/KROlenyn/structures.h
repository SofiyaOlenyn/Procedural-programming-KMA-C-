#pragma once
//structure for task � 6,7
struct Point {
	double _m, _x, _y, _z;
};
//structure for task � 8
struct Point1 {
	double  _x, _y, _z;
};

//structure for task � 9,10
struct Polynom2 {
	int _n = 5;
	int* _coeff = new int[_n];
	int* _exponenta = new int[_n];
};
