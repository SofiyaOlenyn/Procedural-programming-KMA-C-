

#include <iostream>
#include "structures.h"
using namespace std;


//6
double tsentrmas(double** system, const char coord, const unsigned int n)
{
	
	int c(0);
	if (coord == 'x')c = 1;
	if (coord == 'y')c = 2;
	if (coord == 'z')c = 3;
	
	double chuselnik(0), znamennik(0);
	for (int i = 0; i < n; i++) {
		chuselnik = chuselnik+(system[i][0] * system[i][c]);
		znamennik = znamennik+ system[i][0];
		
	}
	
	double result = chuselnik / znamennik;
	
	return result;
}
//7

double tsentrmas2(Point* system, const char coord, const unsigned int n) {
	
	double chuselnik(0), znamennik(0);
	for (int i = 0; i < n; i++) {
		if (coord == 'x')
		chuselnik = chuselnik + (system[i]._m * system[i]._x  );
		if (coord == 'y')
			chuselnik = chuselnik + (system[i]._m * system[i]._y);
		if (coord == 'z')
			chuselnik = chuselnik + (system[i]._m * system[i]._z);

		
		znamennik = znamennik + system[i]._m;
		
	}

	double result = chuselnik / znamennik;

	return result;
} 
//8

//my function to calculate weight
double massa(double x, double y, double z )
{
	return sin(x) + y+z*z;
}

double tsentrmas3(double(*const f)(double x, double y, double z), Point1* system, const char coord, const unsigned int n) {
	double chuselnik(0), znamennik(0);

	for (int i = 0; i < n; i++) {
		double m = f(system[i]._x, system[i]._y, system[i]._z);
		if (coord == 'x')
			chuselnik = chuselnik + (m * system[i]._x);
		if (coord == 'y')
			chuselnik = chuselnik + (m * system[i]._y);
		if (coord == 'z')
			chuselnik = chuselnik + (m * system[i]._z);
		znamennik = znamennik + m;
	}

	double result = chuselnik / znamennik;

	return result;
}

