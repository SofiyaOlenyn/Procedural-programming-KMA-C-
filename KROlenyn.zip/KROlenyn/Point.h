#pragma once
#include "structures.h";
double tsentrmas(double** system, const char coord, const unsigned int n);
;
double tsentrmas2(Point* system, const char coord, const unsigned int n);
;
double massa(double x, double y, double z);
double tsentrmas3(double(*const f)(double x, double y, double z), Point1* system, const char coord, const unsigned int n);