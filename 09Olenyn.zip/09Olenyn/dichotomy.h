#pragma once
double dichotomy(double(*const f)(double), const double a, const double b, const double eps);
double mysinx(double x);
double mysin0(double x);
double myln(double x);
double myexp(double x);