#include <cassert>
using namespace std;
#include <iostream>                                  
#include <cmath>            


double dichotomy(double(*const f)(double), const double a, const double b, const double eps) {
	double c; 
	double left = a, right = b;

	while ((right - left) >= eps)
	{
		c = (left + right) / 2;
		if (f(c) == 0.0) {
		
			break;
		}
		else if (f(c) * f(left) < 0) {
			
			right = c;
		}
		else {
			
			left = c;
		}
	}

   return c; 
}

	
double mysinx (double x)
{
	return sin(x) - x;
}
double mysin0(double x)
{
	return sin(x) ;
}
double myln(double x)
{
	return log(x) - 1;
}
double myexp(double x)
{
	return exp(x) - 2 + x;
}

