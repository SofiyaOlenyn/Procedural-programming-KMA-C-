﻿#include <iostream>
#include "dichotomy.h"
#include <math.h>
#define _USE_MATH_DEFINES
# define M_PI          3.141592653589793238462643383279502884L /* pi */
using namespace std;
int main() {
	/*sin(x) = x, [-1,1];
sin(x) = 0, [π-1, π];
ln(x )= 1, [2, 3];
exp(x)=2-x, [0,2] .*/

	const double asin0 = M_PI - 1, bsin0 = M_PI;
	const double     asinx(-1), aln(2),  aexp(0);
	const double     bsinx(1), bln(3), bexp(2) ;
	const double eps(1.0e-15);
	cout << "sin(x) = x, [-1,1]" << endl;
	cout << "x = " << dichotomy(mysinx, asinx, bsinx, eps) << endl;
	cout << "sin(x) = 0, [pi-1, pi]" << endl;
	cout << "x = " << dichotomy(mysin0, asin0, bsin0, eps) << endl;
	cout << "ln(x )= 1, [2, 3]" << endl;
	cout << "x = " << dichotomy(myln, aln, bln, eps) << endl;
	cout << "exp(x)=2-x, [0,2]" << endl;
	cout << "x = "<< dichotomy(myexp, aexp, bexp, eps) << endl;

	
	system("pause");
}