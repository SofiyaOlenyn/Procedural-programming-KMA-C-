
#include <iostream>
#include <cstdlib> 
#include "Horner.h"
using namespace std;
// 
int main()
{
	/*cout << "������ n";
	int n;
	cin >> n; */

	size_t n1(3), n2(5), n3(5), n4(10), n5(1), n6(3), n7(0);
	const double x1(1), x2(-1), x3(5.2), x4(2), x5(-3), x6(-3.5), x7(2);

	cout << "x=" << x1 <<"  n=" << n1 << endl;
	cout << "Coefficients:  ";
	double* Array = new double[n1+1];
    fillArray( Array , n1);
	cout << endl << "Result:  ";
	Horner(Array, n1, x1 );
	delete[] Array;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" <<  endl;

	cout << "x=" << x2 << "  n=" << n2 << endl;
	cout << "Coefficients:  ";
	double* Array2 = new double[n2 + 1];
	fillArray(Array2, n2);
	cout << endl << "Result:  ";
	Horner(Array2, n2, x2);
	delete[] Array2;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;

	cout << "x=" << x3 << "  n=" << n3 << endl;
	cout << "Coefficients:  ";
	double* Array3 = new double[n3 + 1];
	fillArray(Array3, n3);
	cout << endl << "Result:  ";
	Horner(Array3, n3, x3);
	delete[] Array3;

	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	cout << "x=" << x4 << "  n=" << n4 << endl;
	cout << "Coefficients:  ";
	double* Array4 = new double[n4 + 1];
	fillArray(Array4, n4);
	cout << endl << "Result:  ";
	Horner(Array4, n4, x4);
	delete[] Array4;

	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	cout << "x=" << x5 << "  n=" << n5 << endl;
	cout << "Coefficients:  ";
	double* Array5 = new double[n5 + 1];
	fillArray(Array5, n5);
	cout << endl << "Result:  ";
	Horner(Array5, n5, x5);
	delete[] Array5;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	cout << "x=" << x6 << "  n=" << n6 << endl;
	cout << "Coefficients:  ";
	double* Array6 = new double[n6 + 1];
	fillArray(Array6, n6);
	cout << endl << "Result:  ";
	Horner(Array6, n6, x6);
	delete[] Array6;
	cout << "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" << endl;
	cout << "x=" << x7 << "  n=" << n7 << endl;
	cout << "Coefficients:  ";
	double* Array7 = new double[n7 + 1];
	fillArray(Array7, n7);
	cout << endl << "Result:  ";
	Horner(Array7, n7, x7);
	delete[] Array7;


	


	system("pause");

	return 0;
}