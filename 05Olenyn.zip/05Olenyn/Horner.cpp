#include "Horner.h"
#include <cstdlib> 
#include <cassert>
#include <iostream>
using namespace std;
int getRandomNumber(int min, int max)
{
	static const double fraction = 1.0 / (static_cast<double>(RAND_MAX) + 1.0);
	
	return static_cast<int>(rand() * fraction * (max - min + 1) + min);
}



void fillArray(double* coeff, size_t size)
{

	for (int i = 0; i <= size; i++)
	{
		coeff[i] = getRandomNumber(-100, 100);
		cout << coeff[i] << "  ";
	}
	return;
}

double sum(double* coeff, size_t size, int sign)
{  double k(0);
   double sum= coeff[0];
	for (int i = 1; i <= size; i++) {
		if (i==1 || i%2!=0) {
			sum = sum + coeff[i] * sign;
		}
		else { sum = sum + coeff[i]; }

	}
	return sum;
}
double Horner(double* coeff, size_t size, double x)
{
	double result(0);
	int n = size - 1;
	if (size==0){ 
		result = coeff[0];
		
	}
	else {

		double b2 = 0;
		double b1 = coeff[size];
		for (int i = n; i >= 0; i--) {
			b1 = coeff[i] + b1 * x;
			b2 = b1;

		}
		result = b2;
	}

	assert(((x == 1) || (x == -1)) ? (result == sum(coeff, size, x)) : true);
	cout << result << endl;
	return result;
}
