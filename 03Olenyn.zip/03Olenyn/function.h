#pragma once
double gauss(double x);
double exponentaSimpson(double x);
double exponenta(double x);
double power(double a);
double exponentaSympsonCount(double x);
double powerCount(double a, int n);
double exponentaCount(double x);