using namespace std;
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cmath>
# define EXP          2.71828182846  /* E */
double power(double a, int n) {
	if (n < 0) { cout << "error x"; return -1; }
	double result(1);
	if (n > 0) {
		for (int i = 1; i <= n; i++)
		{
			result = result * a;
			
		};
	}
	return result;
}
double powerCount (double a, int n ) {
	int count=0;
	if (n < 0) { cout << "error x"; return -1; }
	double result(1);
	if (n > 0) {
		for (int i = 1; i <= n; i++)
		{
			count++;
			result = result * a;

		};
	}
	return count;
}
double gauss(double x)
{
	double t = x, i = 0, eps = 0.000000001, s = 0;
	do {
		s += t;
		t *= -x * x * (2 * i + 1) / (2 * i + 3) / (i + 1);
		i++;
	} while (fabs(t) > eps);
	return s;
}
double exponentaCount(double x) {
	int count = 0;
	double eps = 0.000000001;
	double a0(1), sum(1 + x);
	double a1 = x; 
	if (x == 1) { return 1; }
	int i(1);
	while (abs(a1 - a0) > eps) {
		count++;
		i++;
		a0 = a1;
		a1 = a1 * x / i;
		sum = sum + a1;

	}
	return count;
}
double exponenta(double x) {
	double eps = 0.000000001;
	double a0(1), sum(1+x);
	double a1 = x;
	int i(1);
	while (abs(a1 - a0) >eps) {
		
		i++;
		a0 = a1;
		a1 = a1 * x / i;
		sum = sum + a1;
	    
	}
	return sum;
}
double exponentaSimpson(double x) {
	int count(0);
	double intpart;
	double result;
	const double absx = abs(x);
	int wholeP = static_cast <int> (abs(x));
	double fractionP = modf(abs(x), &intpart);
	result = exponenta(fractionP) * power(EXP, wholeP);
	int a = count;
	if (x < 0) { result = 1 / result; };
	return result;



}

double exponentaSympsonCount(double x) {
	int  count=0;
	double intpart;
	double result;
	const double absx = abs(x);
	int wholeP = static_cast <int> (abs(x));
	double fractionP = modf(abs(x), &intpart);
	result = exponentaCount(fractionP) + powerCount(EXP, wholeP);

	if (x < 0) { result++; };
	return result;



}