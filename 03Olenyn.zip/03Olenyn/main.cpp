
#include "function.h";
using namespace std;
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cmath>

using namespace std;
int main() {
	const unsigned int a1(1), a2(2), a3(3), a4(4), a5(5), a6(6), a7(7), a8(8), a9(9), a10(10), count(0);
	cout << "x=" << a1 << endl;
	cout << "Gause : " << gauss(a1) << endl;
	cout << "E in row : " << exponenta(a1) << endl;
	cout << "x=" << a2 << endl;
	cout << "Gause : " << gauss(a2) << endl;
	cout << "E in row : " << exponenta(a2) << endl;
	cout << "x=" << a3 << endl;
	cout << "Gause : " << gauss(a3) << endl;
	cout << "E in row : " << exponenta(a3) << endl;
	cout << "x=" << a4 << endl;
	cout << "Gause : " << gauss(a4) << endl;
	cout << "E in row : " << exponenta(a4) << endl;
	cout << "x=" << a5 << endl;
	cout << "Gause : " << gauss(a5) << endl;
	cout << "E in row : " << exponenta(a5) << endl;
	cout << "x=" << a6 << endl;
	cout << "Gause : " << gauss(a6) << endl;
	cout << "E in row : " << exponenta(a6) << endl;
	cout << "x=" << a7 << endl;
	cout << "Gause : " << gauss(a7) << endl;
	cout << "E in row : " << exponenta(a7) << endl;
	cout << "x=" << a8 << endl;
	cout << "Gause : " << gauss(a8) << endl;
	cout << "E in row : " << exponenta(a8) << endl;
	cout << "x=" << a9 << endl;
	cout << "Gause : " << gauss(a9) << endl;
	cout << "E in row : " << exponenta(a9) << endl;
	cout << "x=" << a10 << endl;
	cout << "Gause : " << gauss(a10) << endl;
	cout << "E in row : " << exponenta(a10) << endl;
	cout << "Calculating the Gaussian interval gives wrong results after 6," << endl;
	cout << "because of incommensurability of additives." << endl;
	cout << "Calculating e in row gives wrong results," << endl;
	cout << "because it works only when xE(0;1)" << endl;
	cout << "So we need use Simpson's rule for right calculation" << endl;
	cout << "Simpson's rule:" << endl;

    
    const double b1(0.2), b2(6.8), b3(2.5), b4(-4), b5(-5.6), b6(7.5), b7(10), b8(-8), b9(30), b10(60);
	
	cout << "e^" << b1 << ":          " << exponentaSimpson(b1) << endl;
	cout << "Rigt answer : " << exp(b1) << endl;
	cout << "e^" << b2 << ":          " << exponentaSimpson(b2) << endl;
	cout << "Rigt answer : " << exp(b2) << endl;
	cout << "e^" << b3 << ":          " << exponentaSimpson(b3) << endl;
	cout << "Rigt answer : " << exp(b3) << endl;
	cout << "e^" << b4 << ":          " << exponentaSimpson(b4) << endl;
	cout << "Rigt answer : " << exp(b4) << endl;
	cout << "e^" << b5 << ":          " << exponentaSimpson(b5) << endl;
	cout << "Rigt answer : " << exp(b5) << endl;
	cout << "e^" << b6 << ":          " << exponentaSimpson(b6) << endl;
	cout << "Rigt answer : " << exp(b6) << endl;
	cout << "e^" << b7 << ":          " << exponentaSimpson(b7) << endl;
	cout << "Rigt answer : " << exp(b7) << endl;
	cout << "e^" << b8 << ":          " << exponentaSimpson(b8) << endl;
	cout << "Rigt answer : " << exp(b8) << endl;
	cout << "e^" << b9 << ":          " << exponentaSimpson(b9) << endl;
	cout << "Rigt answer : " << exp(b9) << endl;
	cout << "e^" << b10 << ":          " << exponentaSimpson(b10) << endl;
	cout << "Rigt answer : " << exp(b10) << endl;

	cout << "/////////////////" << endl;

	cout << "Amount of steps:" << endl;
	cout << "x="<<b1 << endl;
	cout << "E in row steps : " << exponentaCount(b1) << endl;
	cout << "Simpson's rule steps : " << exponentaSympsonCount(b1) << endl;
	cout << "x=" << b2 << endl;
	cout << "E in row steps : " << exponentaCount(b2) << endl;
	cout << "Simpson's rule steps : " << exponentaSympsonCount(b2) << endl;
	cout << "x=" << b3 << endl;
	cout << "E in row steps : " << exponentaCount(b3) << endl;
	cout << "Simpson's rule steps : " << exponentaSympsonCount(b3) << endl;
	cout << "x=" << b4 << endl;
	cout << "E in row steps : " << exponentaCount(b4) << endl;
	cout << "Simpson's rule steps : " << exponentaSympsonCount(b4) << endl;
	cout << "x=" << b5 << endl;
	cout << "E in row steps : " << exponentaCount(b5) << endl;
	cout << "Simpson's rule steps : " << exponentaSympsonCount(b5) << endl;
	cout << "So Simpson's rule take less steps and is more effective" << endl;
	
	return 0;
}