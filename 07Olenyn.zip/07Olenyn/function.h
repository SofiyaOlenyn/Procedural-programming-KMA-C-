#pragma once
#include "structure.h"

int fibonacci(int n);
