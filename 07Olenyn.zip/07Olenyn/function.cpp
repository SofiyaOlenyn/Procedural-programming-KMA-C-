#include <iostream>
#include <math.h>
#include "function.h"
#include "structure.h"
#define _USE_MATH_DEFINES

using namespace std;

    int fibonacci(int n) {
	Matrix2x2  A = { 1,1,1,0 };
	Matrix2x2 res;
	Matrix2x2 B = { 1,1,1,0 };
	Vector2 V = { 1,0 };
	Vector2 V1 ;
	if (n == 0)
		return 0;
	
	A = { 1,1,1,0 };
	for (int i = 2; i < n; i++) {
		res._11 = A._11 * B._11 + A._12 * B._21;
		res._12 = A._11 * B._12 + A._12 * B._22;
		res._21 = A._21 * B._11 + A._22 * B._21;
		res._22 = A._21 * B._12 + A._22 * B._22;
		A._11 = res._11;
		A._12 = res._12;
		A._21 = res._21;
		A._22 = res._22;
		
	}
		V1._1 = A._11 * V._1 + A._12 * V._2;
		V1._2 = A._21 * V._1 + A._22 * V._2;


		return V1._1;
	
}
