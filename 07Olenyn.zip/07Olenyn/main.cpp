#include <iostream>
#include "function.h"
#include "structure.h"
using namespace std;
int main() {
	const int n(1), n1(2), n2(5), n3(10), n4(20) , n5(6), n6(3), n7(4);
	cout << "Fibonacci:" << endl;
	cout<< "number "<< n <<" = "<< fibonacci(n)<<endl;
	cout << "number " << n1 << " = " << fibonacci(n1) << endl;
	cout << "number " << n6 << " = " << fibonacci(n6) << endl;
	cout << "number " << n7 << " = " << fibonacci(n7) << endl;
	cout << "number " << n2 << " = " << fibonacci(n2) << endl;
	cout << "number " << n5 << " = " << fibonacci(n5) << endl;
	cout << "number " << n3 << " = " << fibonacci(n3) << endl;
	cout << "number " << n4 << " = " << fibonacci(n4) << endl;
	
	system("pause");
}